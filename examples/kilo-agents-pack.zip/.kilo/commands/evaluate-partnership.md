---
description: "[Business] Opportunity assessment with technical feasibility"
agent: team-leader
---

# /evaluate-partnership

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/evaluate-partnership <partner> [--integration-type api/data/oem]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/evaluate-partnership` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@business-development-manager` (role 63)
   - Step 2: `@product-manager` (role 4)
   - Step 3: `@legal-counsel` (role 77)
   - Step 4: `@solutions-architect` (role 8)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Opportunity assessment with technical feasibility

## Category
Business
