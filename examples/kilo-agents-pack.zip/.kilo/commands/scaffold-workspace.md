---
description: "[Physics] Workspace with crate skeletons and a units layer"
agent: team-leader
---

# /scaffold-workspace

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/scaffold-workspace <project> [--crates core-math,physics,solver,io,viz,cli] [--units uom/nalgebra]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/scaffold-workspace` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@software-development-engineer` (role 15)
   - Step 2: `@platform-engineer` (role 12)
   - Step 3: `@devops-engineer` (role 13)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Workspace with crate skeletons and a units layer

## Category
Physics
