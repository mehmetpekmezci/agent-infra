---
description: "[Data / Analytics] Executive dashboards and reporting"
agent: team-leader
---

# /build-dashboard

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/build-dashboard <audience> [--metrics <list>] [--refresh]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/build-dashboard` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@business-intelligence-engineer` (role 30)
   - Step 2: `@analytics-engineer` (role 28)
   - Step 3: `@finance-manager-cfo` (role 74)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Executive dashboards and reporting

## Category
Data / Analytics
