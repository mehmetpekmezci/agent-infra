---
description: "[Infra / Ops] Triage, mitigation, communication"
agent: team-leader
---

# /incident

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/incident <alert/issue> [--severity sev1..sev4] [--comms-channel]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/incident` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@incident-manager` (role 81)
   - Step 2: `@site-reliability-engineer` (role 14)
   - Step 3: `@software-development-engineer` (role 15)
   - Step 4: `@technical-support-engineer` (role 66)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Triage, mitigation, communication

## Category
Infra / Ops
