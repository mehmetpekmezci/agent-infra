---
description: "[Physics] Validation report (PO approval)"
agent: team-leader
---

# /validate-physics

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/validate-physics --against <dataset/analytic/paper> [--metric l2/linf/energy-drift] [--threshold 1e-3] [--experts 51,54,55,56]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/validate-physics` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@physicist` (role 50)
   - Step 2: one of `@mechanical-engineer` (54), `@civil-engineer` (55), `@electronics-engineer` (56), `@chemist` (51). Pick the role that fits the target.
   - Step 3: `@software-testing-engineer` (role 40)
4. This command ends with a **Product Owner approval gate**: after the last step, stop, post a decision brief with `@product-owner`, and wait for the human's answer in the issue.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Validation report (PO approval)

## Category
Physics
