---
description: "[Core] Tagged release, changelog, signed artifacts (PO approval)"
agent: team-leader
---

# /release

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/release --version <semver> [--channel stable/rc/nightly] [--rollout canary:N%/full] [--rollback-on slo-breach]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/release` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@release-manager` (role 80)
   - Step 2: `@devops-engineer` (role 13)
   - Step 3: `@configuration-manager` (role 82)
   - Step 4: `@documentation-engineer` (role 47)
   - Step 5: `@technical-writer` (role 48)
4. This command ends with a **Product Owner approval gate**: after the last step, stop, post a decision brief with `@product-owner`, and wait for the human's answer in the issue.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Tagged release, changelog, signed artifacts (PO approval)

## Category
Core
