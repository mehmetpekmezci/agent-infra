---
description: "[Core] Design doc, ADR, threat-model notes"
agent: team-leader
---

# /design-feature

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/design-feature <req-id> [--ui yes/no] [--threat-model yes/no]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/design-feature` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@business-analyst` (role 3)
   - Step 2: one of `@system-architect` (6), `@software-architect` (7). Pick the role that fits the target.
   - Step 3: `@ux-designer` (role 42)
   - Step 4: `@security-engineer` (role 31)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Design doc, ADR, threat-model notes

## Category
Core
