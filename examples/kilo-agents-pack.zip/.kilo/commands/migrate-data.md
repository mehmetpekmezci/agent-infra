---
description: "[Java→Rust] Migration scripts, backfill, reconciliation report"
agent: team-leader
---

# /migrate-data

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/migrate-data --source <db-uri> --dest <db-uri> [--mode dual-write/backfill/snapshot] [--verify checksum/row-diff]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/migrate-data` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@database-administrator` (role 29)
   - Step 2: `@data-engineer` (role 25)
   - Step 3: `@backend-developer` (role 17)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Migration scripts, backfill, reconciliation report

## Category
Java→Rust
