---
description: "[Quality / Security] Benchmarks in CI with threshold gates"
agent: team-leader
---

# /perf-regression

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/perf-regression <crate> [--bench criterion] [--threshold 5%]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/perf-regression` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@performance-engineer` (role 41)
   - Step 2: `@software-test-development-engineer` (role 39)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Benchmarks in CI with threshold gates

## Category
Quality / Security
