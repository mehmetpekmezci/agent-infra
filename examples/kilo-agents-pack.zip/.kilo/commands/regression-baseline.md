---
description: "[Physics] Golden-result store with versioned reference data"
agent: team-leader
---

# /regression-baseline

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/regression-baseline <sim> [--tolerance-rule abs/rel] [--ref-data <dir>]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/regression-baseline` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@software-test-development-engineer` (role 39)
   - Step 2: `@software-quality-assurance-engineer` (role 38)
   - Step 3: `@configuration-manager` (role 82)
4. Apply the default gates (review, QA, security) unless `--gates` says otherwise.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
Golden-result store with versioned reference data

## Category
Physics
