---
description: "[Java→Rust] New flows, design system, prototype spec (PO approval)"
agent: team-leader
---

# /redesign-ux

Run this as the Team Leader. Arguments given: `$ARGUMENTS`

**Signature:** `/redesign-ux <app> [--design-system new/existing] [--platform web/desktop/mobile] [--usability-test]`
**Global parameters:** `[--target] [--scope module/crate/workspace/system] [--depth quick/standard/thorough] [--roles +N,-N] [--gates po,review,qa,security,none] [--priority p0..p3] [--milestone] [--input] [--output] [--budget] [--parent #issue] [--dry-run]`

## Procedure
1. Validate the arguments with the `command-parsing-dispatch` skill. Reject missing required parameters. Apply defaults from `.agents/policy.toml` if it exists. With `--dry-run`, print the planned issue tree and role chain and stop.
2. Open a Gitea epic titled `/redesign-ux` with the `gitea-issue-management` skill. Put the parsed parameters in the issue body as a YAML block.
3. Decompose the epic (`epic-decomposition` skill) and delegate the steps in this order. Each agent hands off with the `role-handoff-protocol` skill:
   - Step 1: `@ux-designer` (role 42)
   - Step 2: `@ui-designer` (role 43)
   - Step 3: `@product-designer` (role 44)
   - Step 4: `@psychologist` (role 46)
   - Step 5: `@ux-researcher` (role 45)
4. This command ends with a **Product Owner approval gate**: after the last step, stop, post a decision brief with `@product-owner`, and wait for the human's answer in the issue.
5. Post a short status summary on the epic: what was produced, where it is, what is still open.

## Expected output
New flows, design system, prototype spec (PO approval)

## Category
Java→Rust
