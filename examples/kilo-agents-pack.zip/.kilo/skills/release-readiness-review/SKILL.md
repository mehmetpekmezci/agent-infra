---
name: release-readiness-review
description: "Check that tests, security, docs and approvals are complete before shipping, and define rollback."
---

# release-readiness-review

Check that tests, security, docs and approvals are complete before shipping, and define rollback.

## Used by
`@release-manager` (80), `@software-quality-assurance-engineer` (38), `@product-owner` (1)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `python3 .kilo/skills/scripts/readiness_check.py --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/readiness_check.py`

`readiness_check.py` aggregates gate status, open blockers and test results into a go/no-go checklist

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
