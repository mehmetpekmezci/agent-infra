---
name: authn-authz-implementation
description: "Implement authentication and authorization (OIDC, JWT, RBAC) and test the permission matrix."
---

# authn-authz-implementation

Implement authentication and authorization (OIDC, JWT, RBAC) and test the permission matrix.

## Used by
`@backend-developer` (17), `@security-engineer` (31), `@full-stack-developer` (18), `@application-security-engineer` (32)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `bash .kilo/skills/scripts/auth_scaffold.sh --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/auth_scaffold.sh`

`auth_scaffold.sh` adds middleware templates and generates negative authorization tests

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
