---
name: legacy-java-analysis
description: "Inventory a Java code base: modules, dependencies, frameworks, JNI and native code, dead code, and hot spots."
---

# legacy-java-analysis

Inventory a Java code base: modules, dependencies, frameworks, JNI and native code, dead code, and hot spots.

## Used by
`@software-architect` (7), `@solutions-architect` (8), `@software-review-engineer` (37), `@business-analyst` (3), `@database-administrator` (29)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `python3 .kilo/skills/scripts/java_inventory.py --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/java_inventory.py`

`java_inventory.py` parses Maven or Gradle files and the class graph and emits a JSON inventory with coupling metrics

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
