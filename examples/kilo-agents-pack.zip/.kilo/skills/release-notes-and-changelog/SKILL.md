---
name: release-notes-and-changelog
description: "Write user-facing release notes and keep the changelog accurate."
---

# release-notes-and-changelog

Write user-facing release notes and keep the changelog accurate.

## Used by
`@technical-writer` (48), `@release-manager` (80), `@documentation-engineer` (47)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `python3 .kilo/skills/scripts/changelog.py --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/changelog.py`

`changelog.py` drafts notes from merged PRs and issue labels using conventional commits

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
