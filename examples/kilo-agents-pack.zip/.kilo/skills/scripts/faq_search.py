#!/usr/bin/env python3
# faq_search.py - `faq_search.py` finds matching FAQ entries and drafts a reply for review
# STATUS: scaffold. Implement the logic, then remove the not_implemented result.
import json, sys


def main(argv):
    dry = "--dry-run" in argv
    args = [a for a in argv if a != "--dry-run"]
    print(json.dumps({"script": "faq_search.py", "status": "not_implemented", "dry_run": dry, "args": args,
                      "note": "scaffold - implement this script before relying on it"}))
    return 3


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
