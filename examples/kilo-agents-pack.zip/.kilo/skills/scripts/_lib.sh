#!/usr/bin/env bash
# Shared helpers for .kilo/skills/scripts/*.sh
# Exit codes: 0 ok | 1 check failed | 2 usage error | 3 not implemented (scaffold)

DRY_RUN=0
ARGS=()
STEPS_JSON=""
FAILED=0

json_str() {
  python3 -c 'import json,sys; print(json.dumps(sys.stdin.read().rstrip("\n")))' <<<"$1"
}

parse_flags() {
  local a
  for a in "$@"; do
    case "$a" in
      --dry-run) DRY_RUN=1 ;;
      -h|--help) usage; exit 0 ;;
      *) ARGS+=("$a") ;;
    esac
  done
}

add_step() {
  local item
  item=$(printf '{"step":%s,"result":%s,"detail":%s}' "$(json_str "$1")" "$(json_str "$2")" "$(json_str "$3")")
  STEPS_JSON="${STEPS_JSON:+$STEPS_JSON,}$item"
}

run_step() {
  local name="$1"; shift
  if [ "$DRY_RUN" = 1 ]; then
    add_step "$name" "skipped" "dry-run: $*"
    return 0
  fi
  local out
  if out=$("$@" 2>&1); then
    add_step "$name" "pass" ""
  else
    FAILED=1
    add_step "$name" "fail" "$(printf '%s' "$out" | tail -n 20)"
  fi
}

finish() {
  local status=pass
  [ "$FAILED" = 1 ] && status=fail
  [ "$DRY_RUN" = 1 ] && status=dry-run
  printf '{"script":%s,"status":%s,"steps":[%s]}\n' "$(json_str "$1")" "$(json_str "$status")" "$STEPS_JSON"
  [ "$FAILED" = 1 ] && exit 1
  exit 0
}

not_implemented() {
  local args_json dry=false
  args_json=$(python3 -c 'import json,sys; print(json.dumps(sys.argv[1:]))' "${ARGS[@]}")
  [ "$DRY_RUN" = 1 ] && dry=true
  printf '{"script":%s,"status":"not_implemented","dry_run":%s,"args":%s,"note":"scaffold - implement this script before relying on it"}\n' "$(json_str "$1")" "$dry" "$args_json"
  exit 3
}
