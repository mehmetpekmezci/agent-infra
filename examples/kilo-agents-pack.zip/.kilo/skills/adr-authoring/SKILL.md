---
name: adr-authoring
description: "Record each architecture decision with context, options, trade-offs and consequences, and check the reasoning for hidden assumptions."
---

# adr-authoring

Record each architecture decision with context, options, trade-offs and consequences, and check the reasoning for hidden assumptions.

## Used by
`@system-architect` (6), `@software-architect` (7), `@solutions-architect` (8), `@security-architect` (35), `@philosopher` (58)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `bash .kilo/skills/scripts/new_adr.sh --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/new_adr.sh`

`new_adr.sh` creates a numbered ADR from a template, sets its status, and updates the ADR index

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
