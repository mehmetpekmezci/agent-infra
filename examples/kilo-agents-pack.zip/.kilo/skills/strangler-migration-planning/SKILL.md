---
name: strangler-migration-planning
description: "Plan incremental migration: module ordering, feature flags, rollback points and cutover criteria."
---

# strangler-migration-planning

Plan incremental migration: module ordering, feature flags, rollback points and cutover criteria.

## Used by
`@project-manager` (5), `@software-architect` (7), `@solutions-architect` (8), `@team-leader` (2)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `python3 .kilo/skills/scripts/migration_plan.py --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/migration_plan.py`

`migration_plan.py` orders modules by coupling and risk and creates the migration epic with per-module issues

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
