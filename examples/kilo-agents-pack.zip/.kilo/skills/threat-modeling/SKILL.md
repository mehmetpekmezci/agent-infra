---
name: threat-modeling
description: "Identify assets, trust boundaries, threats and mitigations (STRIDE, attack trees)."
---

# threat-modeling

Identify assets, trust boundaries, threats and mitigations (STRIDE, attack trees).

## Used by
`@security-engineer` (31), `@security-architect` (35), `@application-security-engineer` (32), `@system-architect` (6)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `python3 .kilo/skills/scripts/stride_gen.py --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/stride_gen.py`

`stride_gen.py` generates a STRIDE table per component from the architecture model and opens mitigation issues

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
