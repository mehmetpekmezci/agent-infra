---
name: technology-selection
description: "Compare technologies against weighted criteria and select with documented rationale (Rust crates, databases, protocols, platforms)."
---

# technology-selection

Compare technologies against weighted criteria and select with documented rationale (Rust crates, databases, protocols, platforms).

## Used by
`@system-architect` (6), `@solutions-architect` (8), `@ml-ai-researcher` (24), `@platform-engineer` (12)

## When to use
Load this skill when the issue you are working on needs the capability above. Read the issue and the latest hand-off comment first, and do only the part that belongs to your role.

## Procedure
1. Read the Gitea issue, the hand-off comment, and the artifacts it points to.
2. Run the helper script first with `--dry-run` to see what it would do, then run it for real:
   `python3 .kilo/skills/scripts/tech_matrix.py --dry-run [args]`
3. Read the script's JSON output. Exit code 0 = ok, 1 = a check failed (report it, do not hide it), 2 = usage error, 3 = scaffold not implemented (do the work manually and say so in the issue).
4. Record results as files in the repository (follow the project layout), and summarize them in an issue comment.
5. Finish with the `role-handoff-protocol` skill so the next role knows what to pick up.

## Scripts
- `scripts/tech_matrix.py`

`tech_matrix.py` scores options against weighted criteria and outputs a comparison table

## Rules
- Rust is the implementation language for all code produced.
- Never close an issue or merge a PR without the required gates (review, QA, security, Product Owner where marked).
- If blocked, say so in the issue and ask the Team Leader (`@team-leader`) to escalate; do not guess.
