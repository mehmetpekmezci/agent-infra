# Kilo agent organization pack

Generated from the 82-role agent roster, the 95-command catalog, and the 131-skill catalog.

## Layout
```
.kilo/
  commands/   95 slash commands, one markdown file each (frontmatter: description, agent)
  agents/     82 agents, one markdown file each (frontmatter: description, mode)
  skills/     131 skills, one folder each with SKILL.md (frontmatter: name, description)
    scripts/  helper scripts used by the skills, shared helpers `_lib.sh` and `_gitea.py`
link-canonical.sh   optional: adds .kilo/agent and .kilo/command symlinks
```
Extract the zip in your project root.

## Things to check before use
- **Directory names.** You asked for `.kilo/commands` and `.kilo/agents`. Kilo's own documentation and CLI use `.kilo/agent` (singular), and the community Kilo port uses `.kilo/command`. `.kilo/skills` (plural) matches the Kilo documentation. If your Kilo version does not pick up the plural folders, run `./link-canonical.sh`.
- **Frontmatter.** Agents use `description` and `mode` (`primary` for the Team Leader, `subagent` for the rest). Commands use `description` and `agent: team-leader`. Skills use `name` (identical to the folder name) and `description`. Check with `kilo debug agent team-leader` and `kilo debug skill`, and adjust if your Kilo version expects other keys (for example `mode:` in commands).
- **Scripts.** 13 of the 132 scripts are working implementations: the Gitea client (`gitea_issue.sh`, `handoff.py`) and the Rust toolchain wrappers (`cargo_check.sh`, `run_tests.sh`, `coverage.sh`, `deps_audit.sh`, `unsafe_report.sh`, `bench.sh`, `crate_graph.sh`, `build_docs.sh`, `fuzz_run.sh`, `miri_loom.sh`, `secret_scan.sh`). The remaining 119 are scaffolds: they accept `--dry-run`, print JSON with `"status":"not_implemented"`, and exit with code 3 so that an agent never mistakes a stub for a passed check.
- **Script conventions.** JSON on stdout. Exit codes: 0 ok, 1 check failed, 2 usage error, 3 not implemented. Tool-dependent scripts need the matching tool installed (cargo-nextest, cargo-llvm-cov, cargo-audit, cargo-deny, cargo-geiger, cargo-fuzz, miri, gitleaks).
- **Gitea.** Set `GITEA_URL`, `GITEA_TOKEN`, and `GITEA_REPO` (owner/repo) in the environment of the agents. Labels such as `role:15` are created automatically when first used.
- **Product Owner.** `product-owner.md` is a brief-writer for the human; it never decides on the human's behalf.
