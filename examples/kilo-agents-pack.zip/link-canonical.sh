#!/usr/bin/env bash
# Kilo CLI's canonical directory names are singular (.kilo/agent, .kilo/command).
# This pack uses plural names (.kilo/agents, .kilo/commands). Run this once from the project root
# to add symlinks so both spellings work.
set -e
cd "$(dirname "$0")/.kilo"
[ -e agent ] || ln -s agents agent
[ -e command ] || ln -s commands command
echo "linked: .kilo/agent -> agents, .kilo/command -> commands"
