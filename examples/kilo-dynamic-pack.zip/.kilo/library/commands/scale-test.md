---
description: "[Physics] Scaling curves and bottleneck report"
agent: team-leader
---
Run `kctx run scale-test $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /scale-test <sim> [--cores N] [--nodes N] [--size-range]
Chain: @performance-engineer -> @site-reliability-engineer -> @cloud-engineer
Output: Scaling curves and bottleneck report. Default gates: review, QA, security.
