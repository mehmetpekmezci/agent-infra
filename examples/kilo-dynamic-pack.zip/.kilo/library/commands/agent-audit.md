---
description: "[Meta] Weak-output analysis and skill-file tuning proposals"
agent: team-leader
---
Run `kctx run agent-audit $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /agent-audit [--period] [--roles <list>]
Chain: @team-leader -> @software-review-engineer
Output: Weak-output analysis and skill-file tuning proposals. Default gates: review, QA, security.
