---
description: "[Business] Customer configuration and onboarding guide"
agent: team-leader
---
Run `kctx run customer-onboarding $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /customer-onboarding <customer> [--config <file>] [--integrations]
Chain: @implementation-specialist -> @customer-success-manager -> @technical-writer
Output: Customer configuration and onboarding guide. Default gates: review, QA, security.
