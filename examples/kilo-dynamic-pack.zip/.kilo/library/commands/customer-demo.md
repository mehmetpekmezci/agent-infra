---
description: "[Business] Demo scenario, PoC, architecture proposal"
agent: team-leader
---
Run `kctx run customer-demo $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /customer-demo <customer> [--scenario <file>] [--poc yes/no]
Chain: @sales-engineer-solutions-consultant -> @software-development-engineer -> @documentation-engineer
Output: Demo scenario, PoC, architecture proposal. Default gates: review, QA, security.
