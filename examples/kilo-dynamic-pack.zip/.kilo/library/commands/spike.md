---
description: "[Core] Research note and recommendation"
agent: team-leader
---
Run `kctx run spike $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /spike <question> [--timebox 2d] [--domain math/physics/ml/arch]
Chain: @ml-ai-researcher/@mathematician/@physicist -> @software-development-engineer
Output: Research note and recommendation. Default gates: review, QA, security.
