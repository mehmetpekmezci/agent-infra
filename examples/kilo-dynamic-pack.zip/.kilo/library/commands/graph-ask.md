---
description: "[Token tools] Answer from the code graph with file references"
agent: team-leader
---
Run `kctx run graph-ask $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /graph-ask <question>
Chain: @software-architect
Output: Answer from the code graph with file references. Default gates: review, QA, security.
