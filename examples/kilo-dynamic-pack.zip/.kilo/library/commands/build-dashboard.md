---
description: "[Data / Analytics] Executive dashboards and reporting"
agent: team-leader
---
Run `kctx run build-dashboard $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /build-dashboard <audience> [--metrics <list>] [--refresh]
Chain: @business-intelligence-engineer -> @analytics-engineer -> @finance-manager-cfo
Output: Executive dashboards and reporting. Default gates: review, QA, security.
