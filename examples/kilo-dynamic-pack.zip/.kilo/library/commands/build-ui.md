---
description: "[Java→Rust] UI implemented against the new design system"
agent: team-leader
---
Run `kctx run build-ui $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /build-ui --design <spec.md> --stack leptos/yew/egui/iced/tauri [--platform web/desktop]
Chain: @frontend-developer/@desktop-developer/@full-stack-developer -> @ui-designer -> @ux-designer
Output: UI implemented against the new design system. Default gates: review, QA, security.
