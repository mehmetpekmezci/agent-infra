---
description: "[Business] Opportunity assessment with technical feasibility"
agent: team-leader
---
Run `kctx run evaluate-partnership $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /evaluate-partnership <partner> [--integration-type api/data/oem]
Chain: @business-development-manager -> @product-manager -> @legal-counsel -> @solutions-architect
Output: Opportunity assessment with technical feasibility. Default gates: review, QA, security.
