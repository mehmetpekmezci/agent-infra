---
description: "[Java→Rust] Retired Java service, archived data and docs"
agent: team-leader
---
Run `kctx run decommission-legacy $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /decommission-legacy <service> [--archive-db yes/no] [--archive-docs yes/no]
Chain: @system-administrator -> @devops-engineer -> @database-administrator -> @documentation-engineer
Output: Retired Java service, archived data and docs. Default gates: review, QA, security.
