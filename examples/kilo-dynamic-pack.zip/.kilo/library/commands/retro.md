---
description: "[Meta] Retrospective and process improvements"
agent: team-leader
---
Run `kctx run retro $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /retro <sprint/milestone>
Chain: @team-leader -> @project-manager -> @operations-manager
Output: Retrospective and process improvements. Default gates: review, QA, security.
