---
description: "[Physics] Optimized code, benchmark gates"
agent: team-leader
---
Run `kctx run optimize-sim $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /optimize-sim <module> [--tools perf,flamegraph] [--target simd/cache/gpu] [--bench-gate]
Chain: @performance-engineer -> @computer-hardware-engineer -> @software-development-engineer
Output: Optimized code, benchmark gates. Default gates: review, QA, security.
