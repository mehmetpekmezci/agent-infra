---
description: "[Java→Rust] Migration guide, manuals, onboarding material"
agent: team-leader
---
Run `kctx run train-and-document $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /train-and-document <system> [--audience dev/user/ops] [--format md/pdf]
Chain: @documentation-engineer -> @technical-writer -> @customer-success-manager
Output: Migration guide, manuals, onboarding material. Default gates: review, QA, security.
