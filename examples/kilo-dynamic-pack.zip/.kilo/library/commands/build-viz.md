---
description: "[Physics] Scientist-oriented visualization UI"
agent: team-leader
---
Run `kctx run build-viz $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /build-viz <sim> [--stack bevy/wgpu/egui] [--mode realtime/offline] [--plots]
Chain: @frontend-developer/@desktop-developer -> @ui-designer -> @ux-designer
Output: Scientist-oriented visualization UI. Default gates: review, QA, security.
