---
description: "[Business] Positioning, messaging, launch checklist"
agent: team-leader
---
Run `kctx run launch-plan $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /launch-plan <product/version> [--segments] [--channels]
Chain: @product-marketing-manager -> @growth-marketer -> @content-seo-specialist -> @product-manager
Output: Positioning, messaging, launch checklist. Default gates: review, QA, security.
