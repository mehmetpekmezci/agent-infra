---
description: "[Token tools] Over-engineering findings with simpler alternatives"
agent: team-leader
---
Run `kctx run ponytail-review $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /ponytail-review [--base <ref>]
Chain: @software-review-engineer -> @software-architect
Output: Over-engineering findings with simpler alternatives. Default gates: review, QA, security.
