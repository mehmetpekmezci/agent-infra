---
description: "[Physics] Solver implementation with physics and math review"
agent: team-leader
---
Run `kctx run implement-solver $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /implement-solver <module> --model <spec.md> [--method rk4/symplectic/implicit] [--tolerance 1e-8] [--backend cpu/rayon/gpu] [--precision f32/f64]
Chain: @software-development-engineer -> @mathematician -> @physicist
Output: Solver implementation with physics and math review. Default gates: review, QA, security.
