---
description: "[Physics] Method choice with stability and error analysis"
agent: team-leader
---
Run `kctx run select-numerics $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /select-numerics <model> [--candidates rk4,symplectic,implicit,fem,fvm] [--stability-analysis]
Chain: @mathematician -> @physicist -> @ml-ai-researcher -> @software-architect
Output: Method choice with stability and error analysis. Default gates: review, QA, security.
