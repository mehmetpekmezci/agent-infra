---
description: "[Java→Rust] New flows, design system, prototype spec (PO approval)"
agent: team-leader
---
Run `kctx run redesign-ux $ARGUMENTS` in the shell and report only its short JSON result. Do not load other files.
Signature: /redesign-ux <app> [--design-system new/existing] [--platform web/desktop/mobile] [--usability-test]
Chain: @ux-designer -> @ui-designer -> @product-designer -> @psychologist -> @ux-researcher
Output: New flows, design system, prototype spec (PO approval). Product Owner approval at the end.
