---
name: mobile-rust-core
description: "Share a Rust core with iOS and Android via uniffi or Tauri mobile and wrap it in native UI."
---
Script: `bash .kilo/skills/scripts/gen_bindings.sh` (run with --dry-run first). gen_bindings.sh generates Swift and Kotlin bindings and checks that the shared API compiles for both targets
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
