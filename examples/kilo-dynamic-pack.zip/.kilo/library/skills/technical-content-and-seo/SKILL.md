---
name: technical-content-and-seo
description: "Plan technical content and SEO and measure search visibility."
---
Script: `python3 .kilo/skills/scripts/seo_audit.py` (run with --dry-run first). seo_audit.py checks pages for titles, metadata and keywords and reports gaps
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
