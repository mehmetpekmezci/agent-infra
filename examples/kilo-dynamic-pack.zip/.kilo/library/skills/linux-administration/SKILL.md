---
name: linux-administration
description: "Configure and maintain OS services, users, permissions, storage and processes."
---
Script: `bash .kilo/skills/scripts/sysaudit.sh` (run with --dry-run first). sysaudit.sh reports failed units, disk usage, users, permissions and open ports
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
