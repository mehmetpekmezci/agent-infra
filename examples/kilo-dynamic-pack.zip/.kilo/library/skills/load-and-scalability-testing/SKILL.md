---
name: load-and-scalability-testing
description: "Test behavior under load and at scale and find bottlenecks."
---
Script: `bash .kilo/skills/scripts/loadtest.sh` (run with --dry-run first). loadtest.sh runs a load tool (oha, k6 or goose) with a profile and reports latency percentiles and errors
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
