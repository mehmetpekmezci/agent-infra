---
name: ml-research-experimentation
description: "Plan experiments, track runs and compare results with scientific rigor."
---
Script: `python3 .kilo/skills/scripts/exp_track.py` (run with --dry-run first). exp_track.py logs parameters, seeds and metrics per run and compares runs
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
