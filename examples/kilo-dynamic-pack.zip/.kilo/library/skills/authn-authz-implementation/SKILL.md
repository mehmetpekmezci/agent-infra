---
name: authn-authz-implementation
description: "Implement authentication and authorization (OIDC, JWT, RBAC) and test the permission matrix."
---
Script: `bash .kilo/skills/scripts/auth_scaffold.sh` (run with --dry-run first). auth_scaffold.sh adds middleware templates and generates negative authorization tests
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
