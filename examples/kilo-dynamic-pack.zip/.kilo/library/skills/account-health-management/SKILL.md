---
name: account-health-management
description: "Track account health, renewals and expansion opportunities."
---
Script: `python3 .kilo/skills/scripts/account_health.py` (run with --dry-run first). account_health.py computes a health score from usage, tickets and sentiment
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
