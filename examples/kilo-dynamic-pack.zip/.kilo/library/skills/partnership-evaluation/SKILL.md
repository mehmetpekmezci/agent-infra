---
name: partnership-evaluation
description: "Assess partnership and market opportunities, fit and risk."
---
Script: `python3 .kilo/skills/scripts/partner_score.py` (run with --dry-run first). partner_score.py scores opportunities against criteria and outputs an assessment table
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
