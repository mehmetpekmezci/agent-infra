---
name: access-and-asset-management
description: "Manage user access, hardware and software assets, and IT policy compliance."
---
Script: `python3 .kilo/skills/scripts/access_review.py` (run with --dry-run first). access_review.py lists users, groups and assets and flags stale or excessive access
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
