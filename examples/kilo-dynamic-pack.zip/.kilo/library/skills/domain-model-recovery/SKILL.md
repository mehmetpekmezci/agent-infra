---
name: domain-model-recovery
description: "Extract business rules, entities and processes from code, schemas and runtime behavior into a domain model."
---
Script: `python3 .kilo/skills/scripts/extract_domain.py` (run with --dry-run first). extract_domain.py builds an entity and rule inventory from source and DB schema and drafts a Mermaid ER diagram
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
