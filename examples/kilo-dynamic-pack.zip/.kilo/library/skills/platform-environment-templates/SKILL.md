---
name: platform-environment-templates
description: "Provide reusable dev and CI environments, scaffolds and golden paths."
---
Script: `bash .kilo/skills/scripts/env_up.sh` (run with --dry-run first). env_up.sh brings up a devcontainer or compose environment with the Rust toolchain and cached builds
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
