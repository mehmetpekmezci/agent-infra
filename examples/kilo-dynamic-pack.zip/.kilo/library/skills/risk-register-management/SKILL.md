---
name: risk-register-management
description: "Identify, score, track and mitigate project risks."
---
Script: `python3 .kilo/skills/scripts/risk_log.py` (run with --dry-run first). risk_log.py appends and updates risks (probability, impact, owner, mitigation) in a versioned file and lists the top risks
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
