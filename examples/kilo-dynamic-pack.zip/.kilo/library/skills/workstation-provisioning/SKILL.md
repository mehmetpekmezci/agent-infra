---
name: workstation-provisioning
description: "Set up developer and staff machines with the toolchain and correct access."
---
Script: `bash .kilo/skills/scripts/provision_ws.sh` (run with --dry-run first). provision_ws.sh installs the Rust toolchain, tools and configuration and verifies versions
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
