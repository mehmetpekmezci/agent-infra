---
name: knowledge-base-sync
description: "Keep the wiki, ADRs and docs aligned with merged work."
---
Script: `python3 .kilo/skills/scripts/wiki_sync.py` (run with --dry-run first). wiki_sync.py updates wiki pages from merged PRs and flags stale pages
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
