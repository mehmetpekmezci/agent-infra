---
name: sales-demo-and-poc
description: "Prepare demos, proof-of-concepts and architecture proposals tied to customer needs."
---
Script: `bash .kilo/skills/scripts/demo_env.sh` (run with --dry-run first). demo_env.sh provisions a disposable demo environment with sample data and resets it after use
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
