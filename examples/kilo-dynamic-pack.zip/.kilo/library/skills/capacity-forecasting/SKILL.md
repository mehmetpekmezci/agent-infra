---
name: capacity-forecasting
description: "Forecast resource needs and cost from load and growth data."
---
Script: `python3 .kilo/skills/scripts/capacity_forecast.py` (run with --dry-run first). capacity_forecast.py fits growth models to usage data and projects capacity and cost
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
