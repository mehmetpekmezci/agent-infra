---
name: firewall-and-dns-configuration
description: "Design and review firewall rules, DNS zones and segmentation."
---
Script: `bash .kilo/skills/scripts/fw_plan.sh` (run with --dry-run first). fw_plan.sh generates nftables rules or cloud security-group diffs in dry-run mode for review
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
