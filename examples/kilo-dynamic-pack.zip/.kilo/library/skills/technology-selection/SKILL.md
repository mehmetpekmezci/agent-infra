---
name: technology-selection
description: "Compare technologies against weighted criteria and select with documented rationale (Rust crates, databases, protocols, platforms)."
---
Script: `python3 .kilo/skills/scripts/tech_matrix.py` (run with --dry-run first). tech_matrix.py scores options against weighted criteria and outputs a comparison table
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
