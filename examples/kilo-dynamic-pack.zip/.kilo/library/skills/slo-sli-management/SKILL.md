---
name: slo-sli-management
description: "Define SLIs and SLOs, error budgets and alerting policy."
---
Script: `python3 .kilo/skills/scripts/slo_calc.py` (run with --dry-run first). slo_calc.py computes SLI values and error-budget burn from metrics
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
