---
name: legacy-ux-audit
description: "Map current journeys, pain points and task friction before a redesign."
---
Script: `python3 .kilo/skills/scripts/journey_map.py` (run with --dry-run first). journey_map.py builds a journey map from interview notes and usage logs
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
