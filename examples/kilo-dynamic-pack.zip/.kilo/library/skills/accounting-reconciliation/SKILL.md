---
name: accounting-reconciliation
description: "Reconcile transactions, maintain records and produce financial reports."
---
Script: `python3 .kilo/skills/scripts/reconcile_ledger.py` (run with --dry-run first). reconcile_ledger.py matches ledger entries to statements and lists unmatched items
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
