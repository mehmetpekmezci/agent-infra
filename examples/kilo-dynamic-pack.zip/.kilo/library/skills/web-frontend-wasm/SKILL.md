---
name: web-frontend-wasm
description: "Build web UIs in Rust (leptos or yew) compiled to WebAssembly with state management and API integration."
---
Script: `bash .kilo/skills/scripts/wasm_build.sh` (run with --dry-run first). wasm_build.sh builds with trunk, checks bundle size, and runs headless browser smoke tests
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
