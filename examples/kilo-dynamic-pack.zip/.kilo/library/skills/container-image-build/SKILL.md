---
name: container-image-build
description: "Build small, reproducible, static Rust images with SBOMs and provenance."
---
Script: `bash .kilo/skills/scripts/build_image.sh` (run with --dry-run first). build_image.sh builds a musl or distroless image, generates an SBOM, and reports image size and layers
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
