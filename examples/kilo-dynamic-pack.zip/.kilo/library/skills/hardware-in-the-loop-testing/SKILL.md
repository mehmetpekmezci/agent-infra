---
name: hardware-in-the-loop-testing
description: "Automate tests that run on real or emulated hardware."
---
Script: `bash .kilo/skills/scripts/hil_run.sh` (run with --dry-run first). hil_run.sh runs the test suite on the board or an emulator and returns a JUnit report
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
