---
name: ux-flow-and-wireframing
description: "Design user flows, information architecture and low-fidelity wireframes."
---
Script: `bash .kilo/skills/scripts/wireframe.sh` (run with --dry-run first). wireframe.sh generates low-fidelity SVG or HTML wireframes from a flow description
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
