---
name: mechanical-and-structural-analysis
description: "Check stress, loads, mechanisms, materials and structural models."
---
Script: `python3 .kilo/skills/scripts/fem_check.py` (run with --dry-run first). fem_check.py runs reference static or modal cases and compares them with the model output
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
