---
name: bug-reproduction
description: "Turn a report into a minimal, reliable reproduction with logs and environment details."
---
Script: `python3 .kilo/skills/scripts/repro_bug.py` (run with --dry-run first). repro_bug.py builds a repro script from ticket data and captures logs and versions
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
