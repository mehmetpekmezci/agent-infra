---
name: requirements-engineering
description: "Elicit, structure and version requirements with unique IDs, priorities and traceability to design, tests and issues."
---
Script: `python3 .kilo/skills/scripts/req_trace.py` (run with --dry-run first). req_trace.py assigns REQ IDs, links them to issues and tests, and reports untested or orphaned requirements
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
