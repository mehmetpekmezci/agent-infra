---
name: data-migration-reconciliation
description: "Migrate data between systems and prove that the target matches the source."
---
Script: `python3 .kilo/skills/scripts/reconcile.py` (run with --dry-run first). reconcile.py compares counts, checksums and sampled rows between source and target
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
