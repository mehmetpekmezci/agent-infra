---
name: database-access-and-migrations
description: "Write typed database access (sqlx or diesel) and reversible schema migrations."
---
Script: `bash .kilo/skills/scripts/migrate.sh` (run with --dry-run first). migrate.sh applies, verifies and rolls back migrations against a throwaway database
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
