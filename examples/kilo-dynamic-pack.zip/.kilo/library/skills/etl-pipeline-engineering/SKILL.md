---
name: etl-pipeline-engineering
description: "Build batch and streaming pipelines for extraction, transformation and loading with idempotency and retries."
---
Script: `bash .kilo/skills/scripts/pipeline_run.sh` (run with --dry-run first). pipeline_run.sh runs a pipeline stage with checkpoints and a row-count and checksum report
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
