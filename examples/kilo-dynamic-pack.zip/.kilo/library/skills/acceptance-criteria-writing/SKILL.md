---
name: acceptance-criteria-writing
description: "Write testable acceptance criteria in Given/When/Then form."
---
Script: `bash .kilo/skills/scripts/gherkin_lint.sh` (run with --dry-run first). gherkin_lint.sh lints feature files and checks that each criterion maps to a REQ ID
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
