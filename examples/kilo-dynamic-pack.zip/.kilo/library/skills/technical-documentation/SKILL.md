---
name: technical-documentation
description: "Write and maintain architecture docs, guides and tutorials with rustdoc and mdBook."
---
Script: `bash .kilo/skills/scripts/build_docs.sh` (run with --dry-run first). build_docs.sh runs cargo doc and mdBook and checks links and code samples
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
