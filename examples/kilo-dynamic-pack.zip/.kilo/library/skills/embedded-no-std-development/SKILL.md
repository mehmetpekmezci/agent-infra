---
name: embedded-no-std-development
description: "Write `no_std` firmware (embassy, RTIC) with HAL crates, memory budgets and real-time constraints."
---
Script: `bash .kilo/skills/scripts/flash_and_test.sh` (run with --dry-run first). flash_and_test.sh builds for the target, flashes with probe-rs, and collects defmt logs
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
