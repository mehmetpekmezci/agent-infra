---
name: ethics-and-assumption-analysis
description: "Examine assumptions, value conflicts and consistency of arguments behind decisions."
---
Script: `python3 .kilo/skills/scripts/assumption_log.py` (run with --dry-run first). assumption_log.py extracts assumptions from design docs and ADRs and tracks which are validated
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
