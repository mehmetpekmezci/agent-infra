---
name: backup-and-restore
description: "Define backup policy and prove that restore works."
---
Script: `bash .kilo/skills/scripts/restore_test.sh` (run with --dry-run first). restore_test.sh restores the latest backup into a scratch instance and runs integrity checks
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
