---
name: hardware-architecture-analysis
description: "Analyze CPU, memory hierarchy, buses and peripherals to guide data layout and optimization."
---
Script: `bash .kilo/skills/scripts/hw_probe.sh` (run with --dry-run first). hw_probe.sh reports CPU features, cache sizes, NUMA topology and memory bandwidth
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
