---
name: support-intake-and-faq
description: "Handle first-line support, maintain FAQs, and communicate status to customers."
---
Script: `python3 .kilo/skills/scripts/faq_search.py` (run with --dry-run first). faq_search.py finds matching FAQ entries and drafts a reply for review
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
