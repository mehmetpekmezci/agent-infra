---
name: contract-and-terms-review
description: "Review contracts, terms and obligations that affect product or delivery."
---
Script: `python3 .kilo/skills/scripts/clause_extract.py` (run with --dry-run first). clause_extract.py extracts key clauses (term, liability, IP, SLA) into a summary table
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
