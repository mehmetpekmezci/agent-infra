---
name: database-performance-and-schema
description: "Design schemas, indexes and queries and fix performance problems."
---
Script: `bash .kilo/skills/scripts/explain_analyze.sh` (run with --dry-run first). explain_analyze.sh runs EXPLAIN ANALYZE on given queries and flags full scans and missing indexes
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
