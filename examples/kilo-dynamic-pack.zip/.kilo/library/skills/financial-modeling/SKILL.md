---
name: financial-modeling
description: "Build budgets, forecasts and cost analyses for decisions."
---
Script: `python3 .kilo/skills/scripts/fin_model.py` (run with --dry-run first). fin_model.py computes scenarios from assumptions and outputs a forecast table
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
