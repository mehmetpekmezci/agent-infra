---
name: ai-feature-integration
description: "Integrate LLM and inference features with prompts, tool calls, guardrails and evaluation sets."
---
Script: `python3 .kilo/skills/scripts/prompt_eval.py` (run with --dry-run first). prompt_eval.py runs a prompt set against the model and scores outputs against expected results
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
