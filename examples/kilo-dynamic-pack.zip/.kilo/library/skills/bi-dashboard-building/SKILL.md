---
name: bi-dashboard-building
description: "Build dashboards and executive reports with consistent definitions."
---
Script: `python3 .kilo/skills/scripts/dashboard_build.py` (run with --dry-run first). dashboard_build.py generates a dashboard spec from metric definitions and validates its queries
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
