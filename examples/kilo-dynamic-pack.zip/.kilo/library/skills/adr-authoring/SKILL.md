---
name: adr-authoring
description: "Record each architecture decision with context, options, trade-offs and consequences, and check the reasoning for hidden assumptions."
---
Script: `bash .kilo/skills/scripts/new_adr.sh` (run with --dry-run first). new_adr.sh creates a numbered ADR from a template, sets its status, and updates the ADR index
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
