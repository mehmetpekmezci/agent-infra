---
name: agent-tool-orchestration
description: "Define agent tools, MCP servers and orchestration flows with permissions and limits."
---
Script: `bash .kilo/skills/scripts/mcp_tool_scaffold.sh` (run with --dry-run first). mcp_tool_scaffold.sh generates an MCP tool stub with schema and a test harness
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
