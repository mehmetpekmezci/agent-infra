---
name: exploratory-analytics
description: "Explore data and report product and business metrics."
---
Script: `python3 .kilo/skills/scripts/eda.py` (run with --dry-run first). eda.py profiles a dataset and produces summary tables and charts
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
