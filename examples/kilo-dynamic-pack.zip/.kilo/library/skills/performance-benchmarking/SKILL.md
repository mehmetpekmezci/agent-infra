---
name: performance-benchmarking
description: "Benchmark, profile and compare performance with statistically sound methods."
---
Script: `bash .kilo/skills/scripts/bench.sh` (run with --dry-run first). bench.sh runs criterion benchmarks, compares to a baseline, and generates a flamegraph
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
