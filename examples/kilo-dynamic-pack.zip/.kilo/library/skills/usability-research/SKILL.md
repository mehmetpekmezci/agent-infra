---
name: usability-research
description: "Plan and analyze interviews and usability studies and create personas and journeys."
---
Script: `python3 .kilo/skills/scripts/survey_analyze.py` (run with --dry-run first). survey_analyze.py summarizes responses and task metrics (success rate, time on task, errors)
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
