---
name: budget-governance
description: "Set financial controls, approvals and investment decisions."
---
Script: `python3 .kilo/skills/scripts/budget_check.py` (run with --dry-run first). budget_check.py compares actual spend to budget by project and flags overruns
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
