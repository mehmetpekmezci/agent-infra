---
name: network-diagnostics
description: "Diagnose DNS, routing, latency, bandwidth and connectivity problems."
---
Script: `bash .kilo/skills/scripts/net_probe.sh` (run with --dry-run first). net_probe.sh runs DNS, ping, traceroute and TCP checks and outputs timing and failure JSON
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
