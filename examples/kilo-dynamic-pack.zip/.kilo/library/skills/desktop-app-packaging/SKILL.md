---
name: desktop-app-packaging
description: "Build and package native desktop apps (egui, iced, tauri) with OS integration and installers."
---
Script: `bash .kilo/skills/scripts/package_desktop.sh` (run with --dry-run first). package_desktop.sh produces deb, AppImage, MSI or dmg packages and verifies they launch
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
