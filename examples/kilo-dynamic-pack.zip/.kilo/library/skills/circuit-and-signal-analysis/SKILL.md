---
name: circuit-and-signal-analysis
description: "Analyze circuits, sensors and signal chains and define hardware and software interfaces."
---
Script: `bash .kilo/skills/scripts/spice_run.sh` (run with --dry-run first). spice_run.sh runs circuit simulations and extracts voltages, timing and spectra
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
