---
name: solution-integration-design
description: "Design how application, data, infrastructure and external systems fit together end to end."
---
Script: `python3 .kilo/skills/scripts/integration_map.py` (run with --dry-run first). integration_map.py generates a system-interface inventory and a data-flow diagram from declared connectors
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
