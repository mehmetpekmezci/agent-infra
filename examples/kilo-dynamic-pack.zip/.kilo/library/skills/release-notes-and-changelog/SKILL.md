---
name: release-notes-and-changelog
description: "Write user-facing release notes and keep the changelog accurate."
---
Script: `python3 .kilo/skills/scripts/changelog.py` (run with --dry-run first). changelog.py drafts notes from merged PRs and issue labels using conventional commits
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
