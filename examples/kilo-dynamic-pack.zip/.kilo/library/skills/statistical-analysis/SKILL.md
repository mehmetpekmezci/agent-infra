---
name: statistical-analysis
description: "Run hypothesis tests, A/B analysis and predictive models with clear assumptions and uncertainty."
---
Script: `python3 .kilo/skills/scripts/ab_test.py` (run with --dry-run first). ab_test.py computes effect size, confidence intervals and significance for an experiment dataset
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
