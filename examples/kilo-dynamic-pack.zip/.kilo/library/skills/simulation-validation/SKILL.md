---
name: simulation-validation
description: "Compare simulation results against analytic cases, benchmarks or experimental data with defined metrics and tolerances."
---
Script: `python3 .kilo/skills/scripts/compare_results.py` (run with --dry-run first). compare_results.py computes L2, Linf and conservation errors against reference data and renders a validation report
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
