---
name: observability-instrumentation
description: "Instrument services with logs, metrics and traces (`tracing`, OpenTelemetry) and build dashboards."
---
Script: `bash .kilo/skills/scripts/otel_check.sh` (run with --dry-run first). otel_check.sh verifies that spans, metrics and log fields are emitted and exported
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
