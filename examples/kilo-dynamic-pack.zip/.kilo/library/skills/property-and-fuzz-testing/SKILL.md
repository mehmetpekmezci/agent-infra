---
name: property-and-fuzz-testing
description: "Test invariants with `proptest` and find crashes with `cargo-fuzz`."
---
Script: `bash .kilo/skills/scripts/fuzz_run.sh` (run with --dry-run first). fuzz_run.sh runs a time-boxed fuzz campaign, minimizes crashes, and files them as issues
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
