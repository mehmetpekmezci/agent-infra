---
name: model-evaluation
description: "Design evaluation methodology, metrics, baselines and error analysis."
---
Script: `python3 .kilo/skills/scripts/eval_report.py` (run with --dry-run first). eval_report.py computes metrics and confusion or error slices and renders a markdown report
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
