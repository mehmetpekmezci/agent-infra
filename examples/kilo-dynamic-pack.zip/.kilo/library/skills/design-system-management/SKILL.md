---
name: design-system-management
description: "Maintain visual language, components, typography and design tokens."
---
Script: `python3 .kilo/skills/scripts/tokens_export.py` (run with --dry-run first). tokens_export.py converts design tokens into CSS variables and Rust constants
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
