---
name: ml-pipeline-engineering
description: "Build training, evaluation and inference pipelines in Rust (burn, candle, ONNX runtime)."
---
Script: `bash .kilo/skills/scripts/train_eval.sh` (run with --dry-run first). train_eval.sh runs the pipeline with a fixed seed, records metrics and artifacts, and fails on a metric regression
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
