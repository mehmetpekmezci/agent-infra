---
name: biological-model-validation
description: "Validate biological models and interpret biological data."
---
Script: `python3 .kilo/skills/scripts/bio_check.py` (run with --dry-run first). bio_check.py runs model outputs against reference datasets and checks plausibility ranges
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
