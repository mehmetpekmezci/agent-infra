---
name: physics-model-specification
description: "Write the governing equations, assumptions, units, boundary conditions and validity range of a model."
---
Script: `python3 .kilo/skills/scripts/model_spec_lint.py` (run with --dry-run first). model_spec_lint.py checks that the spec defines all symbols, units and boundary conditions
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
