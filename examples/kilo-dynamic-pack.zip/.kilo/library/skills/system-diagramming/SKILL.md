---
name: system-diagramming
description: "Produce context, container, component and deployment diagrams as code."
---
Script: `bash .kilo/skills/scripts/render_diagram.sh` (run with --dry-run first). render_diagram.sh renders Mermaid, PlantUML or D2 sources to SVG and checks that referenced components exist
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
