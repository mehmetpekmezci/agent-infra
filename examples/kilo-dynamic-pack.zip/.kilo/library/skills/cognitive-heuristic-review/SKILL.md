---
name: cognitive-heuristic-review
description: "Review designs for cognitive load, human factors and usability heuristics."
---
Script: `python3 .kilo/skills/scripts/heuristic_checklist.py` (run with --dry-run first). heuristic_checklist.py applies a heuristic checklist to a design spec and lists violations
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
