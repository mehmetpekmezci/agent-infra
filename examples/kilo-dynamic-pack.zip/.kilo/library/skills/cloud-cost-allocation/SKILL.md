---
name: cloud-cost-allocation
description: "Attribute cloud and compute costs to products and teams and find savings."
---
Script: `python3 .kilo/skills/scripts/cost_report.py` (run with --dry-run first). cost_report.py pulls billing exports and groups spend by tag, service and project
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
