---
name: interface-and-api-design
description: "Design stable interfaces and contracts (traits, REST via OpenAPI, gRPC via protobuf) with versioning rules."
---
Script: `bash .kilo/skills/scripts/api_lint.sh` (run with --dry-run first). api_lint.sh lints OpenAPI and proto files and checks for breaking changes against the previous version
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
