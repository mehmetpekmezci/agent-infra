---
name: rust-code-implementation
description: "Implement features in idiomatic Rust: ownership, error handling with `Result`, traits, modules, tests and docs."
---
Script: `bash .kilo/skills/scripts/cargo_check.sh` (run with --dry-run first). cargo_check.sh runs fmt, clippy, build and test and returns a structured pass or fail summary
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
