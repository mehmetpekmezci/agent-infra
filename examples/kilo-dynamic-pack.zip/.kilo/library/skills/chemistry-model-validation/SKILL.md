---
name: chemistry-model-validation
description: "Validate chemical models, kinetics and material properties."
---
Script: `python3 .kilo/skills/scripts/kinetics_check.py` (run with --dry-run first). kinetics_check.py checks rate laws, mass balance and thermodynamic consistency
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
