---
name: test-strategy-planning
description: "Plan test levels, coverage targets, environments and quality gates from requirements and risk."
---
Script: `python3 .kilo/skills/scripts/test_plan.py` (run with --dry-run first). test_plan.py generates a test matrix from requirement IDs and risk ratings
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
