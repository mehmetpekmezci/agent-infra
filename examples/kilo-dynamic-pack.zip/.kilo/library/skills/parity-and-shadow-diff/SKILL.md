---
name: parity-and-shadow-diff
description: "Compare legacy and new systems on the same inputs and classify differences."
---
Script: `python3 .kilo/skills/scripts/shadow_diff.py` (run with --dry-run first). shadow_diff.py replays or mirrors traffic to both systems and diffs normalized responses
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
