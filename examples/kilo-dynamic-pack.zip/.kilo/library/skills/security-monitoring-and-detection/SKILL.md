---
name: security-monitoring-and-detection
description: "Monitor logs and signals, detect threats and investigate anomalies."
---
Script: `python3 .kilo/skills/scripts/log_hunt.py` (run with --dry-run first). log_hunt.py runs detection queries over logs and outputs ranked suspicious events
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
