---
name: retrospective-and-process-metrics
description: "Measure cycle time, lead time and rework, run retrospectives, and propose process changes."
---
Script: `python3 .kilo/skills/scripts/process_metrics.py` (run with --dry-run first). process_metrics.py computes cycle and lead times and reopen rates from Gitea history
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
