---
name: mathematical-modeling-and-proofs
description: "Build formal models and check derivations, proofs and complexity."
---
Script: `python3 .kilo/skills/scripts/symbolic_check.py` (run with --dry-run first). symbolic_check.py verifies derivations and identities symbolically with sympy
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
