---
name: internal-tooling
description: "Build and maintain internal tools, automation and productivity infrastructure."
---
Script: `bash .kilo/skills/scripts/tool_scaffold.sh` (run with --dry-run first). tool_scaffold.sh generates a Rust CLI or service template wired into CI and the docs
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
