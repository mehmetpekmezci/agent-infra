---
name: compliance-evidence-collection
description: "Map controls to requirements and collect audit evidence."
---
Script: `bash .kilo/skills/scripts/evidence_collect.sh` (run with --dry-run first). evidence_collect.sh gathers CI logs, approvals and scan reports per control into an evidence folder
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
