---
name: roadmap-prioritization
description: "Prioritize features and shape the roadmap with a transparent scoring model tied to customer value and cost."
---
Script: `python3 .kilo/skills/scripts/score_backlog.py` (run with --dry-run first). score_backlog.py scores issues (RICE or WSJF) and outputs a ranked backlog
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
