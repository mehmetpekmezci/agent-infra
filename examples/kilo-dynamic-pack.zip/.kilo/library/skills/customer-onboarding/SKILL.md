---
name: customer-onboarding
description: "Guide customers to adoption with checklists, configuration and training."
---
Script: `python3 .kilo/skills/scripts/onboarding_check.py` (run with --dry-run first). onboarding_check.py tracks onboarding milestones per customer and flags stalled steps
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
