---
name: async-service-development
description: "Build async services with tokio, axum or tonic, including configuration, graceful shutdown and health endpoints."
---
Script: `bash .kilo/skills/scripts/scaffold_service.sh` (run with --dry-run first). scaffold_service.sh generates a service skeleton with config, tracing and health routes
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
