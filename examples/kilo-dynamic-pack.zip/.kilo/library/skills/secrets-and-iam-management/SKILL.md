---
name: secrets-and-iam-management
description: "Manage secrets, access policies, and least privilege in cloud and CI."
---
Script: `bash .kilo/skills/scripts/secret_scan.sh` (run with --dry-run first). secret_scan.sh scans the repo and history for secrets and lints IAM policies for over-broad permissions
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
