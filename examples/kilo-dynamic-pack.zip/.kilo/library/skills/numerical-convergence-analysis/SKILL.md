---
name: numerical-convergence-analysis
description: "Choose methods and demonstrate order of convergence, stability and error bounds."
---
Script: `python3 .kilo/skills/scripts/convergence_study.py` (run with --dry-run first). convergence_study.py runs refinement series and fits the observed convergence order
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
