---
name: epic-decomposition
description: "Break an epic into child issues with owners, estimates, dependencies and acceptance criteria."
---
Script: `python3 .kilo/skills/scripts/decompose_epic.py` (run with --dry-run first). decompose_epic.py creates child issues from templates and links them as blockers or dependents
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
