---
name: growth-experimentation
description: "Design and measure acquisition, activation and retention experiments."
---
Script: `python3 .kilo/skills/scripts/growth_funnel.py` (run with --dry-run first). growth_funnel.py computes funnel conversion by cohort and tracks experiments
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
