---
name: memory-and-concurrency-verification
description: "Verify memory safety and concurrency behavior (`miri`, `loom`, sanitizers, cache analysis)."
---
Script: `bash .kilo/skills/scripts/miri_loom.sh` (run with --dry-run first). miri_loom.sh runs miri, loom and sanitizer builds and summarizes findings
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
