---
name: api-reference-generation
description: "Generate and verify API references that match the code."
---
Script: `bash .kilo/skills/scripts/gen_api_docs.sh` (run with --dry-run first). gen_api_docs.sh builds OpenAPI and rustdoc references and fails on undocumented public items
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
