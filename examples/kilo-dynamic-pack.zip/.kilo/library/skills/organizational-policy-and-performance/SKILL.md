---
name: organizational-policy-and-performance
description: "Maintain employee policies and performance processes and align operations."
---
Script: `python3 .kilo/skills/scripts/policy_index.py` (run with --dry-run first). policy_index.py tracks policy versions and review dates and flags overdue reviews
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
