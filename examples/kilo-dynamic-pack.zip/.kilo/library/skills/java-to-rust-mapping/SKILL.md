---
name: java-to-rust-mapping
description: "Define idiomatic Rust equivalents for Java constructs (classes to structs and traits, exceptions to `Result`, GC patterns to ownership)."
---
Script: `python3 .kilo/skills/scripts/scaffold_port.py` (run with --dry-run first). scaffold_port.py generates Rust module skeletons and TODO notes from Java signatures using a mapping table
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
