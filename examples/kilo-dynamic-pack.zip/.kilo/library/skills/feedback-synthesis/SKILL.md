---
name: feedback-synthesis
description: "Combine tickets, surveys, interviews and usage data into themes that feed the roadmap."
---
Script: `python3 .kilo/skills/scripts/feedback_themes.py` (run with --dry-run first). feedback_themes.py clusters feedback text, counts themes, and links representative issues
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
