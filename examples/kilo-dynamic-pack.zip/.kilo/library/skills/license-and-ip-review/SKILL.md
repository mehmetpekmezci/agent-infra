---
name: license-and-ip-review
description: "Review software licenses, intellectual property and legal risk."
---
Script: `python3 .kilo/skills/scripts/license_check.py` (run with --dry-run first). license_check.py classifies dependency licenses against the allowed policy and generates a notice file
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
