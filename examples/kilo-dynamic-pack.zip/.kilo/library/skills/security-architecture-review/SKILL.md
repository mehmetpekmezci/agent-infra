---
name: security-architecture-review
description: "Review trust boundaries, identity architecture and defense in depth."
---
Script: `python3 .kilo/skills/scripts/trust_boundary_check.py` (run with --dry-run first). trust_boundary_check.py checks the architecture model for flows that cross boundaries without a control
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
