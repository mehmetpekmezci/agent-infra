---
name: data-quality-management
description: "Define and enforce data-quality rules: completeness, uniqueness, validity and freshness."
---
Script: `python3 .kilo/skills/scripts/dq_check.py` (run with --dry-run first). dq_check.py evaluates rule sets against tables and outputs violations
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
