---
name: customer-implementation
description: "Configure, deploy and integrate the product for a specific customer."
---
Script: `bash .kilo/skills/scripts/customer_config.sh` (run with --dry-run first). customer_config.sh renders and validates customer-specific configuration and runs an integration smoke test
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
