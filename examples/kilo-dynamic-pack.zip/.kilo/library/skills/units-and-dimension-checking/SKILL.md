---
name: units-and-dimension-checking
description: "Prevent unit and dimension errors with typed units in code and checks on specs."
---
Script: `python3 .kilo/skills/scripts/dimension_check.py` (run with --dry-run first). dimension_check.py checks equations for dimensional consistency and flags raw floats in public APIs
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
