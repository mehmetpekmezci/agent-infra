---
name: product-positioning-and-messaging
description: "Define positioning, segments, messaging and competitive framing."
---
Script: `python3 .kilo/skills/scripts/positioning_canvas.py` (run with --dry-run first). positioning_canvas.py fills a positioning template from product docs and competitor notes
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
