---
name: test-harness-and-fixtures
description: "Build reusable harnesses, mocks, fakes, simulators and fixtures."
---
Script: `bash .kilo/skills/scripts/scaffold_harness.sh` (run with --dry-run first). scaffold_harness.sh generates a harness crate with fixture builders and mock traits
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
