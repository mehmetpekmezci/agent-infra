---
name: hiring-pipeline
description: "Define role needs, sourcing, interview kits and hiring workflow."
---
Script: `python3 .kilo/skills/scripts/interview_kit.py` (run with --dry-run first). interview_kit.py generates a rubric and question set from the role requirements
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
