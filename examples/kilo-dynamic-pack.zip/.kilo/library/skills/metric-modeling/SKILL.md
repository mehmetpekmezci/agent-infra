---
name: metric-modeling
description: "Define canonical metrics and transformation models with tests and documentation."
---
Script: `python3 .kilo/skills/scripts/metric_lint.py` (run with --dry-run first). metric_lint.py checks metric definitions for ambiguity and duplicates and verifies their SQL or Polars logic
Do: read the issue and the hand-off, apply this skill, save results in the repo, report in the hand-off.
