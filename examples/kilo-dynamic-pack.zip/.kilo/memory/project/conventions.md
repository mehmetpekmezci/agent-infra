---
title: "Project conventions"
tags: [conventions]
---
Edit this file. Put stable project facts here (language, crate layout, branch rules, definition of done). `kctx recall` finds them by keyword.
