---
description: "Run a workflow with small-context staging: /kctx <command> [args]"
agent: team-leader
---
Run `kctx run $ARGUMENTS` in the shell and report only its short JSON result. Use `kctx catalog --type command` to list commands. Do not load other files.
