# Dynamic context pack for small context windows

Built for a ~32K-token model. Almost everything lives in a cold **library** (about 37743 tokens in total, never loaded together). Kilo only discovers what is in the active folders, and `kctx` copies the few items a step needs into them and removes them afterwards.

## Memory levels
| Level | What | Where | In context |
|---|---|---|---|
| L0 core | rules, orchestrator agent, 2 universal skills, `/kctx` router | `.kilo/memory/L0-core.md`, pinned items | always (about 755 tokens) |
| L1 working set | one agent + up to 3 skills for the current step | `.kilo/agents|skills|commands` (copied from `.kilo/library`) | only during that step |
| L2 task memory | rolling epic summary (max 2400 bytes) + latest hand-off | `.kilo/memory/epics/<id>/` | every step of that epic |
| L3 project memory | decisions, conventions, epic digests | `.kilo/memory/project/` | only by `kctx recall`, max 2400 bytes |
| L4 org memory | cross-project lessons and conventions | `~/.kilo/memory/org/` | only by `kctx recall` |
| catalog | one line per agent/skill/command, plus the command-to-agent graph | `.kilo/catalog/` | only via `kctx catalog|search|plan` |

## How a workflow runs
`./kctx run port-module billing --from java:legacy/billing --to rust:crates/billing`
1. Validates the arguments and builds the plan: step order, agent per step, and the 1 to 3 most relevant skills per step.
2. Creates epic `E0001` (and a Gitea issue if `GITEA_URL`, `GITEA_TOKEN`, `GITEA_REPO` are set).
3. For every step: unload everything not pinned, load that step's agent and skills, build a prompt (L0 rules + L2 summary + recalled L3/L4 notes + step instructions), start a **fresh** session with `kilo run`, read the hand-off file the agent wrote, truncate it to 1200 bytes, update the rolling summary, unload.
4. Stops at blocked or needs-input hand-offs, at the human Product Owner gates (`kctx resume E0001 --approve` after the human decided), or when the chain is finished. Then `kctx close E0001` stores a short digest in L3.

Because each step is a new session, a skill loaded in step 3 is never in the context of step 4, and the Team Leader session only ever sees a short JSON result.

## Useful commands
```
kctx status                    budget table and what is loaded
kctx plan <command> [args]     show steps, skills and fixed-context cost (no changes)
kctx catalog --type skill      compact list;  kctx search "fuzz parser"
kctx load skill <name>         manual load (LRU eviction when over budget);  kctx unload --all
kctx pack list|load|unload     load a group of slash commands (for example java-rust)
kctx recall "<query>"          search L3/L4 (BM25, no extra services)
kctx remember 3 "<title>" --text "..."     save a note (max 1500 bytes)
kctx epics | resume <id> [--approve] | close <id>
```

## Things to check
- **Budget.** `.kilo/memory/budget.json` assumes a 32,768-token window (1 token ~ 4 bytes). If you literally mean 32 KB (about 8,000 tokens), use the values in the `_notes` field.
- **Runner.** `run.cmd` defaults to `kilo run --agent {agent}` with the prompt as the last argument. I could not verify those flags for your Kilo version. Change `run.cmd` (or set `KILO_RUN_CMD`); if it contains `{prompt_file}`, the command is run through bash with the prompt file path substituted.
- **Directory names.** Same note as before: Kilo uses `.kilo/agent` and `.kilo/command` (singular); run `./link-canonical.sh` if the plural folders are not picked up. Skills use `.kilo/skills`.
- **Skills are chosen by keyword overlap** between the command and the skill descriptions, not by a model. Check `kctx plan` output; override a role choice with `--prefer N`.
- **Better recall.** Built-in recall is keyword search. To use your own vector or wiki service for L3/L4, set `KCTX_RECALL_CMD` to a command that takes `<query> <max_bytes>` and prints text.
- **Scripts.** 13 of 132 scripts are working; the rest are scaffolds that exit with code 3 (see the first pack's notes).
