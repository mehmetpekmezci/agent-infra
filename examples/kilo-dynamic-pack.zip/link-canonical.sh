#!/usr/bin/env bash
# Kilo's canonical directory names are singular (.kilo/agent, .kilo/command). This pack uses plural names.
# Run once from the project root if your Kilo version does not discover the plural folders.
# NOTE: kctx load/unload writes to the plural folders; the symlinks make both names point to the same files.
set -e
cd "$(dirname "$0")/.kilo"
[ -e agent ] || ln -s agents agent
[ -e command ] || ln -s commands command
echo "linked: .kilo/agent -> agents, .kilo/command -> commands"
